﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace groupedmean
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> value = new List<double>();
            List<double> frequency = new List<double>();
            foreach(string s in textBox1.Text.Split(","))
            {
                frequency.Add(double.Parse(s.Split("x")[1]));
                double val = (double.Parse(s.Split("x")[0].Split("-")[0]) +
                    double.Parse(s.Split("x")[0].Split("-")[1])) / 2;
                value.Add(val);
            }
            MessageBox.Show((frequency.Zip(value, (e1, e2) => e1 * e2).Sum() /
                frequency.Sum()).ToString());

        }
    }
}
